# Modularity Review Checklist

This checklist evaluates whether the module follows basic modularity principles.



1. Single Responsibility  
   Does the module perform exactly one well defined task?

2. Clear Inputs and Outputs  
   Are inputs minimal and explicitly passed? Are outputs clearly returned or handled?

3. Cohesion  
   Are all internal operations strongly related to the main purpose of the module?

4. Low Coupling  
   Does the module avoid relying on external or global data? (Independent of other parts)

5. Reusability  
   Can this module be reused in another program or context without changes?

6. Descriptive Naming  
   Is the module name meaningful and does it reflect the purpose of the module?

7. Input Validation (if applicable)  
   Does the module include basic checks or validation if it receives user input?

8. Length and Simplicity  
   Is the module short enough to be readable and maintainable?

