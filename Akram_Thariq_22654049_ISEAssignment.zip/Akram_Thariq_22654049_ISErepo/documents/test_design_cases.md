#Updated after review: cleaned up formatting and fixed a few notes from earlier draft.

#Test Design Cases

 1. Equivalence Partitioning

 1.1 Module: parse_birthday()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Testing valid formats, invalid formats (structure), and non-numeric input.

| Test Case | Input          | Category | Description                    | Expected Output              |
|-----------|----------------|----------|--------------------------------|------------------------------|
| TC1       | "13-11-1987"   | EP1      | Valid date format              | [13, 11, 1987]               |
| TC2       | "31-12-2001"   | EP1      | Valid leap-year-end date       | [31, 12, 2001]               |
| TC3       | "1987-11-13"   | EP2      | Incorrect format (Y-M-D)       | Error - wrong format        |
| TC4       | "13/11/1987"   | EP2      | Wrong delimiter (slash used)   | Error - wrong format        |
| TC5       | "ab-cd-efgh"   | EP3      | Non-numeric input              | Error: Must be numeric parts |

---

 1.2 Module: calculate_life_path()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers regular life paths, master numbers, and invalid input scenarios.

| Test Case | Input (D, M, Y) | Category | Description                      | Expected Output |
|-----------|------------------|----------|----------------------------------|-----------------|
| TC1       | 13, 11, 1987     | EP2      | Produces a master number (22)    | 22              |
| TC2       | 9, 9, 1999       | EP1      | Produces a regular number (9)    | 9               |
| TC3       | 29, 2, 2000      | EP1      | Leap year, valid date            | 6               |
| TC4       | 0, 0, 0          | EP3      | Invalid input                    | Error / Refactor needed |

---

 1.3 Module: is_master_number()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers valid master numbers and non-master values.

| Test Case | Input | Category | Description               | Expected Output |
|-----------|-------|----------|---------------------------|-----------------|
| TC1       | 11    | EP1      | Valid master number       | True            |
| TC2       | 22    | EP1      | Valid master number       | True            |
| TC3       | 33    | EP1      | Valid master number       | True            |
| TC4       | 9     | EP2      | Not a master number       | False           |
| TC5       | 44    | EP3      | Outside defined masters   | False           |

---

 1.4 Module: get_lucky_color()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers mapped numbers, master numbers, and invalid/unmapped numbers.

| Test Case | Input | Category | Description               | Expected Output |
|-----------|-------|----------|---------------------------|-----------------|
| TC1       | 1     | EP1      | Valid mapped number       | "Red"           |
| TC2       | 7     | EP1      | Valid mapped number       | "Violet"        |
| TC3       | 22    | EP2      | Master number             | "White"         |
| TC4       | 15    | EP3      | Undefined number          | "Unknown"       |
| TC5       | -1    | EP3      | Invalid number            | "Unknown"       |

---

 1.5 Module: get_generation()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers every generation range + invalid years.

| Test Case | Input | Category | Description                 | Expected Output       |
|-----------|-------|----------|-----------------------------|-----------------------|
| TC1       | 1940  | EP1      | Silent Generation           | "Silent Generation"   |
| TC2       | 1960  | EP2      | Baby Boomer                 | "Baby Boomer"         |
| TC3       | 1985  | EP4      | Millennial                  | "Millennial"          |
| TC4       | 2024  | EP6      | Generation Alpha            | "Generation Alpha"    |
| TC5       | 1899  | EP7      | Invalid (too early)         | "Invalid year range"  |

---

 1.6 Module: compare_life_paths()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Tests equality, greater than, and less than conditions.

| Test Case | Inputs (A, B) | Category | Description         | Expected Output                            |
|-----------|---------------|----------|---------------------|--------------------------------------------|
| TC1       | 5, 5          | EP1      | Same Life Path      | "Both people have the same Life Path..."   |
| TC2       | 7, 3          | EP2      | A is greater         | "Person A has a higher Life Path..."       |
| TC3       | 2, 9          | EP3      | B is greater         | "Person B has a higher Life Path..."       |

 2. Boundary Value Analysis (BVA)

 2.1 Module: get_generation()
- Test Design Approach - Boundary Value Analysis (BVA)
- Explanation - Boundary points used to check generation classification at range edges and out-of-bounds cases.

| Test Case | Input | Boundary Type       | Description                          | Expected Output         |
|-----------|-------|---------------------|--------------------------------------|-------------------------|
| TC1       | 1924  | Just below minimum  | Before Silent Generation             | Invalid year range      |
| TC2       | 1925  | Min valid           | First valid Silent Generation year   | Silent Generation       |
| TC3       | 1945  | Max of Silent       | End of Silent Gen                    | Silent Generation       |
| TC4       | 1946  | Start of Boomer     | Transition to next generation        | Baby Boomer             |
| TC5       | 2025  | Max valid           | Latest supported year                | Generation Alpha        |
| TC6       | 2026  | Just above max      | Beyond supported range               | Invalid year range      |
| TC7       | 4049  | Student ID match    | Year based on student ID             | Invalid year range      |

---

 2.2 Module: calculate_life_path()
- Test Design Approach - Boundary Value Analysis (BVA)
- Explanation - Date boundaries and reduction logic tested using edge days, months, and special master number triggers.

| Test Case | Input (D, M, Y) | Boundary Type     | Description                        | Expected Output |
|-----------|------------------|-------------------|------------------------------------|-----------------|
| TC1       | 1, 1, 1900       | Minimum edge      | Earliest date values               | 3               |
| TC2       | 31, 12, 2025     | Maximum edge      | Latest supported values            | 7               |
| TC3       | 11, 11, 2000     | Master trigger    | Adds to 22                         | 22              |
| TC4       | 13, 11, 4049     | Student ID check  | Year from student ID               | 5               |
| TC5       | 0, 0, 0          | Invalid input     | Edge case with all zeroes          | Error/Refactor  |

---

 3. White-Box Testing

---

 3.1 Module: parse_birthday()
- Test Design Approach - White-Box Testing (WBT)
- Constructs Tested: Loop (user input retry), nested conditional checks
- Explanation - This module uses a `while` loop to repeatedly prompt the user until valid input is received. The internal logic checks for correct format (e.g., dash-separated), correct length, and digit-only parts. This test set ensures each conditional path and loop exit condition is covered.

| Test Case | Input             | Path Covered                          | Expected Output               |
|-----------|-------------------|---------------------------------------|-------------------------------|
| TC1       | "13-11-1987"      | Valid on first try → exit loop        | [13, 11, 1987]                |
| TC2       | "13/11/1987"      | Fails format → loop once → then valid | Error, then [13, 11, 1987]    |
| TC3       | "abcd-ef-ghij"    | Fails numeric check → retries         | Error, re-enter prompted      |
| TC4       | "" then "13-11-1987" | Empty input → loop, then valid     | Retry once → [13, 11, 1987]   |
| TC5       | "Ahamed-11-4049"  | Last name + Student ID as input       | Error - wrong format         |

---

 3.2 Module: compare_life_paths()
- Test Design Approach - White-Box Testing (WBT)
- Constructs Tested: Multiple `if-elif-else` conditions
- Explanation - This function contains 3 logical branches: equality, A > B, and A < B. Each test case forces a different branch to ensure full decision coverage.

| Test Case | Inputs (A, B) | Path Covered             | Expected Output                            |
|-----------|---------------|--------------------------|--------------------------------------------|
| TC1       | 4, 4          | A == B                   | "Both people have the same Life Path..."   |
| TC2       | 7, 3          | A > B                    | "Person A has a higher Life Path..."       |
| TC3       | 2, 9          | A < B                    | "Person B has a higher Life Path..."       |

