Does the module have single responsibility?
Yes
Comments: It only compares two values and reports if they're the same. No extra logic is mixed in.

Are all inputs passed explicitly (no global variables)?
Yes
Comments: It uses two arguments and doesn't rely on any external data.

Are outputs clearly returned or displayed?
Yes
Comments: It prints a simple message indicating if the values are equal.

Is the module cohesive (does it contain only related logic)?
Yes
Comments: Everything in the function is focused solely on comparison.

Is the module independent (low coupling)?
Yes
Comments: It doesn’t interact with other modules or rely on shared data.

Is the function name descriptive and accurate?
Yes
Comments: compare_life_paths clearly explains what the function does.

Does the module avoid duplicating functionality from elsewhere?
Yes
Comments: It only handles comparison — no overlapping tasks with calculation or input functions.

Is the code reasonably short and easy to read?
Yes
Comments: Very short and easy. Straightforward use of conditionals.

Is basic input validation included (if applicable)?
Not applicable
Comments: Assumes the inputs are valid numbers from earlier processing steps.
