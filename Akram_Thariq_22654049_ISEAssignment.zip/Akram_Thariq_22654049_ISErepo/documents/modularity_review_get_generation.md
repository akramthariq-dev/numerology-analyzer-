Does the module have single responsibility?  
Yes  
Comments: It only checks the year and returns a matching generation. The logic is focused and simple.

Are all inputs passed explicitly (no global variables)?  
Yes  
Comments: The year is passed directly; no external data is used.

Are outputs clearly returned or displayed?  
Yes  
Comments: The generation name is returned, and the calling code handles display.

Is the module cohesive (does it contain only related logic)?  
Yes  
Comments: The conditionals and logic all relate to age-based generation identification.

Is the module independent (low coupling)?  
Yes  
Comments: It’s fully self-contained and doesn’t call or depend on other modules.

Is the function name descriptive and accurate?  
Yes  
Comments: `get_generation` clearly describes the purpose of the function.

Does the module avoid duplicating functionality from elsewhere?  
Yes  
Comments: Generation logic is only here — no repetition.

Is the code reasonably short and easy to read?  
Yes  
Comments: The structure is very beginner-friendly and easy to follow.

Is basic input validation included (if applicable)?  
Yes  
Comments: It checks for out-of-range years and returns "Invalid year range" if necessary.
