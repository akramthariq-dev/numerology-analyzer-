 Module Descriptions ISE Assignment
Akram Thariq – Student ID: 22654049  



 1. parse_birthday()

Purpose:  
This function takes a user entered birthday in DD-MM-YYYY format, validates it and thene xtracts the day, month and year as integers, If the invalid input is detected (only day and month entered for example) the user is prompted again until a valid format is entered.

Inputs:  
 birthday_str (string): a date input provided via keyboard or test function.

Outputs:  
 A valid datetime.date object that can be passed into other modules.

Input Method: Keyboard via (input), but can also be passed directly.  
Output Method: Return value.

Design Notes:  
This module keeps parsing logic separate from the rest of the program. That way, if input formats need to change later, the logic is isolated. It also helps with testing, since it doesn’t rely on hardcoded inputs.



 2. calculate_life_path()

Purpose:  
Calculates the Life Path number based on a persons date of birth, using the reduction method outlined in the assignment (including handling master numbers).

Inputs:  
- day (int): Day of birth  
- month (int): Month of birth  
- year (int): Year of birth

Outputs:  
 An integer Life Path number, typically 1–9, or one of the master numbers 11, 22, or 33. (int: Life path number, single digit or master number)

Input Method: Function arguments (passed directly without user input) 
Output Method: Returns value.

Design Notes:  
This function calculates the life path number from a given date, it includes logic to reduce numbers to a single digit unless the number is a master number (11, 22 or 33). The function is designed to be running by itself without user inputs.

 3. is_master_number()

Purpose:  
Checks whether a given number is a master number (11, 22, or 33), which shouldn't be reduced in Life Path calculations.

Inputs:  
 n (int)

Outputs:  
 Boolean (True if it is a master number, otherwise False)

Input Method: Passed as argument.
Output Method: Return value.

Design Notes:  
This is a small helper function. By separating it from the main calculation module, the code becomes easier to read and update. It can also be tested independently.


 4. get_lucky_color()

Purpose:  
Returns the lucky color associated with a Life Path number, using the provided chart (Figure 1).

Inputs:  
 life_path_num (int)

Outputs:  
 A string representing the lucky color.

Input Method: Function argument passed  
Output Method: Printed to the console.

Design Notes: 
This function simply maps numbers to color values. When giving the program a number it gives the color that corresponds to that color in figure 1



 5. get_generation()

Purpose:  
Determines which generation group a person belongs to based on their year of birth, using the definitions provided in Figure 2.

Inputs:  
 An integer representing the birth year,  given by the user

Outputs:  
 A string representing the generation label (e.g. "Millennial").

Input Method:
Prompts user for age

Output Method:
Return value

Design Notes:  
This function is a clean readable series of conditional checks with no dependencies.

 6. compare_life_paths(lp1,lp2)

Purpose:  
Given two dates, this function calculates each person’s Life Path number and checks if they match.

Inputs:  
 lp1 and lp2, life path of person a and b

Outputs:  
 Prints the result of the comparison to the console.

Input Method: Arguments
Output Method: Console output.

Design Notes:  
The function focuses only on comparison logic and doesn't compute the numbers themselves as it will be done later.


 Summary of Modularity Considerations

These module designs follow key principles from Lecture 7:
 Each function is responsible for a single, welldefined task (high cohesion).
 No function relies on global state or shared flags (low coupling).
 Parameters and return values are used consistently to transfer data.
 The overall structure leaves room for refactoring later, which will be handled in Step 3.

The input/output methods and data types are intentionally varied across modules. This was done to ensure that testing in Step 4 will be able to demonstrate different forms of data handling, as required in the assignment.

