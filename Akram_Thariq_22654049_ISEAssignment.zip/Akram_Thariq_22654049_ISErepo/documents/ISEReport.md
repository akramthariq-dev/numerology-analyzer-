#ISAD1000 Software Engineering Assignment Report

Name: Akram Thariq
Student ID: 22654049
Class Time:

1) Introduction

The assignment was meant to test our application of the concepts we learned, such as version control, modularity, white-box and black-box testing, and other lessons taught throughout the unit. I think the scenario given is a way to not just apply all of it but also include a bit more difficulty so we go out on our own and research and see what we can use.

While testing the test_ise_modules.py file, I kept running into errors. I tried many times to figure out what went wrong by examining the individual files and then the test file itself, and after a lot of quick tinkering, I figured it out.

I found the Final Program was the most fun, it was really fast and easy since I had already done the hard work making the building blocks until then. All I had to do was just add a few basic lines of code to make it user input based and user friendly. It’s similar to stacking a long line of dominos and then flicking one to watch them all fall; a lot of effort, and the last step is the quickest and most satisfying.

I worked mostly from scratch, but I did use website tutorials as well as YouTube to help me in some cases where I was stuck. Sometimes I just referred back to the lecture slides.

I feel much more confident in my fundamentals of the concepts learned. Git helped me realise how software projects and progress tracking is done. I would personally still use Windows in the future, as I'm more familiar with it and find it easier.

2) Module Descriptions

Below is a list of all the core modules used in the program. Each one was written to perform a single, clear task so that the program would stay modular and easy to test:


parse_birthday(birthday_str):
Takes a string input in the format DD-MM-YYYY and returns a list containing day, month, and year as integers. Validates the input to ensure it’s in the correct format and contains numeric parts.


calculate_life_path(day, month, year):
Calculates a numerology Life Path Number from a given date. Master numbers (11, 22, 33) are preserved instead of reduced.



is_master_number(number):
Checks if a given number is a numerology master number (11, 22, or 33) and returns `True` or `False`.



get_lucky_color(life_path):
Returns a lucky colour based on the life path number. If the number is unknown or not covered, returns "Unknown".



get_generation(year):
Returns the generation a person belongs to based on their birth year. Returns an error message if the year is outside the defined range.



compare_life_paths(num1, num2):
Compares two life path numbers and returns a string message stating which one is higher, or if they are the same.

3) Modularity

 How to Run the Production Code:

To run the final version of the program, open the terminal in Linux  and navigate to the folder where the `FinalProgram.py` file is saved. Then run the command "python3 FinalProgram.py" (pressing tab after F automatically fills it in)

This will prompt the user to enter their birthdate in DD-MM-YYYY format. The program will then calculate and display:
- The Life Path Number
- Whether it is a Master Number
- The Lucky Colour
- The Generation Group

The program handles invalid inputs with clear error messages.

- ![First Code](images/FinalProgram1stCode.png)
- ![First Run](images/FinalProgram1stRun.png)
- ![Second Run](images/FinalProgram2ndRun.png)
- ![Third Run](images/FinalProgram3rdRun.png)
- ![Final Output](images/FinalProgramLastRun.png)


Modularity Principles:

I designed the program using modularity principles from Lecture 7. Each module has a single responsibility, clear input/output, and no unnecessary dependencies. For example:

- `parse_birthday()` only handles input formatting.
- `calculate_life_path()` only focuses on digit reduction.
- `is_master_number()` is used only for checking 11, 22, or 33.

Each function can be tested independently, using this structure made debugging easier and also allowed me to reuse the same logic in the final integrated program.

Modularity Checklist and Review-

Review checklist:

1. Single Responsibility  
   Does the module perform exactly one well defined task?

2. Clear Inputs and Outputs  
   Are inputs minimal and explicitly passed? Are outputs clearly returned or handled?

3. Cohesion  
   Are all internal operations strongly related to the main purpose of the module?

4. Low Coupling  
   Does the module avoid relying on external or global data? (Independent of other parts)

5. Reusability  
   Can this module be reused in another program or context without changes?

6. Descriptive Naming  
   Is the module name meaningful and does it reflect the purpose of the module?

7. Input Validation (if applicable)  
   Does the module include basic checks or validation if it receives user input?

8. Length and Simplicity  
   Is the module short enough to be readable and maintainable?


I used the modularity checklist from the above list to review all my modules, I confirmed:
- Each module had one clear purpose
- Inputs and outputs were well-defined
- No unnecessary code was included
- All code was easy to read and test

Based on this review, I also made a few refactoring edits:

- I added validation to `parse_birthday()` so that it could handle invalid formats so it doesn't crash on a user mistake.
- I updated `calculate_life_path()` to correctly preserve master numbers instead of reducing them by default.
- I improved the clarity of return values and error messages in some modules.

I’ve included screenshots of my checklist and code reviews:
- ![Checklist Screenshot](images/modularity_checklist_commit.png)
- ![parse_birthday Review](images/modularity_review_parse_birthday.png)
- ![compare_life_paths Review](images/compare_life_paths_initial_code_AND_testing.png)

Revised Module Descriptions After Refactoring-

Changes made after updating and fixing the code(s):

- `parse_birthday()` now includes input validation and better error handling.
- `calculate_life_path()` now correctly handles master numbers.
- `main_program.py` was added to bring all modules together into a single working program.

(See updated module descriptions in Section 2.)

4) Black-box Test Cases

Test Design Methods Used-

I used two main black box testing methods:

1. Equivalence Partitioning (EP)  This helped me test normal vs invalid categories of input.
2. Boundary Value Analysis (BVA)  This helped test around the edge cases (e.g., min/max date or generation limits).

Each test case was designed in a table format based on the Lecture 8 guidelines. I tested all modules using EP, and some using BVA where it made sense (like date and generation range boundaries).

Assumptions i made:
- The user will enter the date in the correct format (DD-MM-YYYY), but I added validation for errors.
- Life path numbers outside 1–33 should return "Unknown" for color.
- Generations are based on fixed ranges provided in the assignment (e.g. Silent Generation < 1945, Gen Z around 1997–2012).


Test Case Tables-

#Updated after review: cleaned up formatting and fixed a few notes from earlier draft.

#Test Design Cases

 1. Equivalence Partitioning

 1.1 Module: parse_birthday()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Testing valid formats, invalid formats (structure), and non-numeric input.

| Test Case | Input          | Category | Description                    | Expected Output              |
|-----------|----------------|----------|--------------------------------|------------------------------|
| TC1       | "13-11-1987"   | EP1      | Valid date format              | [13, 11, 1987]               |
| TC2       | "31-12-2001"   | EP1      | Valid leap-year-end date       | [31, 12, 2001]               |
| TC3       | "1987-11-13"   | EP2      | Incorrect format (Y-M-D)       | Error - wrong format        |
| TC4       | "13/11/1987"   | EP2      | Wrong delimiter (slash used)   | Error - wrong format        |
| TC5       | "ab-cd-efgh"   | EP3      | Non-numeric input              | Error: Must be numeric parts |

---

 1.2 Module: calculate_life_path()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers regular life paths, master numbers, and invalid input scenarios.

| Test Case | Input (D, M, Y) | Category | Description                      | Expected Output |
|-----------|------------------|----------|----------------------------------|-----------------|
| TC1       | 13, 11, 1987     | EP2      | Produces a master number (22)    | 22              |
| TC2       | 9, 9, 1999       | EP1      | Produces a regular number (9)    | 9               |
| TC3       | 29, 2, 2000      | EP1      | Leap year, valid date            | 6               |
| TC4       | 0, 0, 0          | EP3      | Invalid input                    | Error / Refactor needed |

---

 1.3 Module: is_master_number()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers valid master numbers and non-master values.

| Test Case | Input | Category | Description               | Expected Output |
|-----------|-------|----------|---------------------------|-----------------|
| TC1       | 11    | EP1      | Valid master number       | True            |
| TC2       | 22    | EP1      | Valid master number       | True            |
| TC3       | 33    | EP1      | Valid master number       | True            |
| TC4       | 9     | EP2      | Not a master number       | False           |
| TC5       | 44    | EP3      | Outside defined masters   | False           |

---

 1.4 Module: get_lucky_color()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers mapped numbers, master numbers, and invalid/unmapped numbers.

| Test Case | Input | Category | Description               | Expected Output |
|-----------|-------|----------|---------------------------|-----------------|
| TC1       | 1     | EP1      | Valid mapped number       | "Red"           |
| TC2       | 7     | EP1      | Valid mapped number       | "Violet"        |
| TC3       | 22    | EP2      | Master number             | "White"         |
| TC4       | 15    | EP3      | Undefined number          | "Unknown"       |
| TC5       | -1    | EP3      | Invalid number            | "Unknown"       |

---

 1.5 Module: get_generation()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Covers every generation range + invalid years.

| Test Case | Input | Category | Description                 | Expected Output       |
|-----------|-------|----------|-----------------------------|-----------------------|
| TC1       | 1940  | EP1      | Silent Generation           | "Silent Generation"   |
| TC2       | 1960  | EP2      | Baby Boomer                 | "Baby Boomer"         |
| TC3       | 1985  | EP4      | Millennial                  | "Millennial"          |
| TC4       | 2024  | EP6      | Generation Alpha            | "Generation Alpha"    |
| TC5       | 1899  | EP7      | Invalid (too early)         | "Invalid year range"  |

---

 1.6 Module: compare_life_paths()
- Test Design Approach - Equivalence Partitioning (EP)
- Explanation - Tests equality, greater than, and less than conditions.

| Test Case | Inputs (A, B) | Category | Description         | Expected Output                            |
|-----------|---------------|----------|---------------------|--------------------------------------------|
| TC1       | 5, 5          | EP1      | Same Life Path      | "Both people have the same Life Path..."   |
| TC2       | 7, 3          | EP2      | A is greater         | "Person A has a higher Life Path..."       |
| TC3       | 2, 9          | EP3      | B is greater         | "Person B has a higher Life Path..."       |

 2. Boundary Value Analysis (BVA)

 2.1 Module: get_generation()
- Test Design Approach - Boundary Value Analysis (BVA)
- Explanation - Boundary points used to check generation classification at range edges and out-of-bounds cases.

| Test Case | Input | Boundary Type       | Description                          | Expected Output         |
|-----------|-------|---------------------|--------------------------------------|-------------------------|
| TC1       | 1924  | Just below minimum  | Before Silent Generation             | Invalid year range      |
| TC2       | 1925  | Min valid           | First valid Silent Generation year   | Silent Generation       |
| TC3       | 1945  | Max of Silent       | End of Silent Gen                    | Silent Generation       |
| TC4       | 1946  | Start of Boomer     | Transition to next generation        | Baby Boomer             |
| TC5       | 2025  | Max valid           | Latest supported year                | Generation Alpha        |
| TC6       | 2026  | Just above max      | Beyond supported range               | Invalid year range      |
| TC7       | 4049  | Student ID match    | Year based on student ID             | Invalid year range      |

---

 2.2 Module: calculate_life_path()
- Test Design Approach - Boundary Value Analysis (BVA)
- Explanation - Date boundaries and reduction logic tested using edge days, months, and special master number triggers.

| Test Case | Input (D, M, Y) | Boundary Type     | Description                        | Expected Output |
|-----------|------------------|-------------------|------------------------------------|-----------------|
| TC1       | 1, 1, 1900       | Minimum edge      | Earliest date values               | 3               |
| TC2       | 31, 12, 2025     | Maximum edge      | Latest supported values            | 7               |
| TC3       | 11, 11, 2000     | Master trigger    | Adds to 22                         | 22              |
| TC4       | 13, 11, 4049     | Student ID check  | Year from student ID               | 5               |
| TC5       | 0, 0, 0          | Invalid input     | Edge case with all zeroes          | Error/Refactor  |


5) White-box Test Cases

I selected two modules to test using White-box testing, parse_birthday() and calculate_life_path(). These were chosen because they contain multiple conditional branches and logic paths that can be tested using path-based techniques (e.g., decision testing, branch testing, condition testing).



 ---

 3. White-Box Testing

---

 3.1 Module: parse_birthday()
- Test Design Approach - White-Box Testing (WBT)
- Constructs Tested: Loop (user input retry), nested conditional checks
- Explanation - This module uses a `while` loop to repeatedly prompt the user until valid input is received. The internal logic checks for correct format (e.g., dash-separated), correct length, and digit-only parts. This test set ensures each conditional path and loop exit condition is covered.

| Test Case | Input             | Path Covered                          | Expected Output               |
|-----------|-------------------|---------------------------------------|-------------------------------|
| TC1       | "13-11-1987"      | Valid on first try → exit loop        | [13, 11, 1987]                |
| TC2       | "13/11/1987"      | Fails format → loop once → then valid | Error, then [13, 11, 1987]    |
| TC3       | "abcd-ef-ghij"    | Fails numeric check → retries         | Error, re-enter prompted      |
| TC4       | "" then "13-11-1987" | Empty input → loop, then valid     | Retry once → [13, 11, 1987]   |
| TC5       | "Ahamed-11-4049"  | Last name + Student ID as input       | Error - wrong format         |

---

 3.2 Module: compare_life_paths()
- Test Design Approach - White-Box Testing (WBT)
- Constructs Tested: Multiple `if-elif-else` conditions
- Explanation - This function contains 3 logical branches: equality, A > B, and A < B. Each test case forces a different branch to ensure full decision coverage.

| Test Case | Inputs (A, B) | Path Covered             | Expected Output                            |
|-----------|---------------|--------------------------|--------------------------------------------|
| TC1       | 4, 4          | A == B                   | "Both people have the same Life Path..."   |
| TC2       | 7, 3          | A > B                    | "Person A has a higher Life Path..."       |
| TC3       | 2, 9          | A < B                    | "Person B has a higher Life Path..."       |


Assumptions:

- The code was assumed to be executed in a Linux environment using Python 3.
- Each function is tested independently, assuming no external/global dependencies.
- I assumed that master numbers (11, 22, 33) should be preserved and not reduced, based on numerology rules given in the assignment.

6) Test implementationand test execution:

How to Run the Test Code:
To run the test suite, make sure you are in the same directory as `test_ise_modules.py`, then open the Linux terminal and enter "python3 test_ise_modules.py"
This runs all the unit tests for the different modules using Python’s built-in `unittest` framework.

Test Execution Results-

After fixing initial bugs, I was able to get all 13 test cases to pass successfully.
The following screenshot shows the final test result:
![Test Success](images/FinalProgramLastRun.png)

Results and Improvements-

During the test implementation, I encountered a few bugs:

- `parse_birthday()` was first written to use `input()` and didn’t accept arguments. I refactored it to take a string input so it could be tested directly.
- `calculate_life_path()` was returning reduced values even for master numbers like 11 and 22. I fixed the logic so that master numbers are preserved.
- I also adjusted a test case that incorrectly expected the Life Path Number for 09-09-1999 to be 9, it is actually 1 after full reduction.

Once these issues were fixed, all test cases passed, and the modules became easier to maintain and reuse.

Bugs/Setbacks i encountered:
- ![1st Fail](images/FinalProgram1stRun.png)
- ![2nd Fail](images/FinalProgram2ndRun.png)
- ![3rd Fail](images/FinalProgram3rdRun.png)

7) Traceability Matrix:


| Module Name             | BB (EP) | BB (BVA) | WB   | Data Type(s)        | Input / Output Form                | EP   | BVA  | WB   |
|-------------------------|---------|----------|------|----------------------|---------------------------------- |------|------|------|
| parse_birthday()        | Yes     | Yes      | Yes  | String, Int          | Input (keyboard) to Output (list) | Yes  | Yes  | Yes  |
| calculate_life_path()   | Yes     | Yes      | Yes  | Int                  | Params to Return Int              | Yes  | Yes  | Yes  |
| is_master_number()      | Yes     | No       | No   | Int to Bool           | Parameter to Return Boolean      | Yes  | No   | No   |
| get_lucky_color()       | Yes     | No       | No   | Int to String         | Parameter to Return String       | Yes  | No   | No   |
| get_generation()        | Yes     | No      | No   | Int to String         | Parameter to Return String       | Yes  | No  | No   |
| compare_life_paths()    | Yes     | No       | No   | Int                  | Parameter to Return String        | Yes  | No   | No   |

8) Version Control:

Throughout the assignment, I used Git as my version control system to manage my files and track progress. I created a local repository using `git init` and committed my work at different stages such as:

- After writing initial module functions
- After refactoring for modularity
- After writing tests
- After fixing bugs based on test results
- After integrating everything into the final program

This helped me organize my changes and go back if something threw up an error. I made a git log file called git_log.txt, a sample is:

commit dc4fcdcbd943fa097c3410a406f54c4b6312086e
Author: Akram <22654049@student.curtin.edu.au>
Date:   Mon Mar 31 01:02:11 2025 +0800

    parse_birthday works for DD-MM-YYYY format, needs error handling and validation loop incase wrong format is entered

commit 6f0a3ff12428533258bdcd612e067fb7441291a4
Author: Akram <22654049@student.curtin.edu.au>
Date:   Mon Mar 31 00:42:41 2025 +0800

    Edited description in get_lucky_color to make it more concise and professional

commit f10497734e26f379b8595c1c2f4859b8d683554e
Author: Akram <22654049@student.curtin.edu.au>
Date:   Mon Mar 31 00:29:24 2025 +0800

    Wrote initial version of module descriptions based on assignment scnearo given

commit d80f44db73d4b496a537dfcbd49377f080651509
Author: Akram <22654049@student.curtin.edu.au>
Date:   Sun Mar 30 23:26:29 2025 +0800

    Updated README to reflect repo naming and structure guidelines

commit 34c949b2a57656995cc13186d022733bcbcec07b
Author: Akram <22654049@student.curtin.edu.au>
Date:   Sun Mar 30 22:39:47 2025 +0800

    Started the assignment repo, added the ode and document folders and the README.txt

Git Log Screenshot

The screenshot below shows my Git commit history when starting. I made commits after writing modules, running tests, fixing bugs, and building the final program. Some of these are grouped under the same session because I committed multiple changes together, the full history can be seen in the folder in a text file.

![Git Commit Log of when i started:](images/git_init_log_ss1.png)

I didn't commit after every tiny change, I grouped commits logically to reflect real progress (e.g., one for writing test cases, one for bug fixes, etc.).

My `.gitignore` file was used to exclude unnecessary system files and temporary files from being tracked.


9) Discussion

Im proud of persevering through and finishing this assignment. I started it quite late and ended up working almost two days nonstop. At the beginning, I didn’t know where to start or how to go about things, but eventually, through hard work and persistence, I managed to get the code working properly and organized everything well. Seeing it all come together was a big relief and something I feel really satisfied about.

The hardest challenge I faced was during testing, especially with the test_ise_modules.py file. I kept running into confusing errors and tried multiple times to figure out what was wrong. I tried many times to figure out what went wrong by examining the individual files then the test file it self,then I finally figured it out and got everything working the way it was supposed to.

I wish i could make features that make it more interactive friendly, just in general. For example, I could have added more input validation to improve the user experience. Through this assignment I learned how software engineers theselves handle projects, and how all the different concepts we learned tie together. Overall, I feel much more confident in my understanding of the fundamentals and how to apply them in real life future scenarios.
