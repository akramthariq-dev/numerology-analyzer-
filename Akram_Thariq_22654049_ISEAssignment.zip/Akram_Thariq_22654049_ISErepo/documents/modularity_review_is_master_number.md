Does the module have single responsibility?  
Yes  
Comments: The function checks if a number is a master number (11, 22, 33) — no extra logic or tasks are included.

Are all inputs passed explicitly (no global variables)?  
Yes  
Comments: The number to check is passed directly to the function; nothing depends on external variables.

Are outputs clearly returned or displayed?  
Yes  
Comments: The function returns a boolean value (True or False) clearly, which can be used by other modules.

Is the module cohesive (does it contain only related logic)?  
Yes  
Comments: Every line of code is directly related to checking if a number is a master number.

Is the module independent (low coupling)?  
Yes  
Comments: It doesn’t rely on any other parts of the program and can be used anywhere it's imported.

Is the function name descriptive and accurate?  
Yes  
Comments: The name `is_master_number` clearly reflects the function’s purpose.

Does the module avoid duplicating functionality from elsewhere?  
Yes  
Comments: The check is only handled here and not hardcoded into other modules, improving reusability.

Is the code reasonably short and easy to read?  
Yes  
Comments: It’s just one line of logic, making it very beginner-friendly and clean.

Is basic input validation included (if applicable)?  
Not applicable  
Comments: Since the input is expected to be a number from elsewhere in the system, the function assumes it is an integer.
