Project folder for ISAD1000 Assignment:
 -code: source and test code
 	-images: Screenshots taken throughout the assignment to document process
 -documents: test plans, checklist and report
 
This repository follows the required naming and version control requirements git

Main Program Files:
- FinalProgram.py  
	The complete integrated program that takes user input and outputs the life path number, lucky color, and generation.

Module Files:
- parse_birthday.py  
   Extracts and validates day, month, and year from a given DD-MM-YYYY string input.
  
- calculate_life_path.py  
   Calculates the numerology life path number based on birth date.
  
- is_master_number.py  
   Checks if a number is a master number (11, 22, or 33).
  
- get_lucky_color.py  
   Returns a lucky color based on life path number.
  
- get_generation.py  
   Determines the generational category based on the birth year.
  
- compare_life_paths.py  
   Compares two life path numbers and outputs the higher or if they’re the same.

Test Files:
- test_ise_modules.py  
   Contains unit test cases written for each module (using unittest).

Documentation & Report:
- AkramThariq_22654049_ISEReport.md  
   Full assignment report, including introduction, modularity, test designs, implementation, and discussion.
  
- module_descriptions.md  
   Written descriptions of each core module in the system.

- test_design_cases.md  
   All black-box and white-box test cases documented in a table format.

- modularity_checklist.md  
   Checklist used to assess modularity principles in each module.

- modularity_review_*.md (various)  
   Reviews of individual modules with refactoring notes and modularity analysis.

Version Control:
- .gitignore  
   Files and folders excluded from version control (e.g. system files, backups).

- git_log.txt  
   Git log containing snapshots of my version history across development phases.

Screenshots:
- All `.png` images in /images folder  
   Screenshots of program runs, test results, modularity reviews, and version control logs for documentation.

History Backups:
- hist version *.text  
   Older versions of my progress saved across development.
