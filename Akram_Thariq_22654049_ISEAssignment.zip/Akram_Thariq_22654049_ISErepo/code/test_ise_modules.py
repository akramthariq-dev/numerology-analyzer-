import unittest
from calculate_life_path import calculate_life_path
from compare_life_paths import compare_life_paths
from get_generation import get_generation
from get_lucky_color import get_lucky_color
from is_master_number import is_master_number
from parse_birthday import parse_birthday

class TestISEModules(unittest.TestCase):

    def test_calculate_life_path_regular(self):
        self.assertEqual(calculate_life_path(9, 9, 1999), 1)

    def test_calculate_life_path_master(self):
        self.assertEqual(calculate_life_path(13, 11, 1987), 22)

    def test_calculate_life_path_invalid(self):
        self.assertEqual(calculate_life_path(9, 9, 1999), 1)

    def test_generation_silent(self):
        self.assertEqual(get_generation(1940), "Silent Generation")

    def test_generation_invalid(self):
        self.assertEqual(get_generation(4049), "Invalid year range")

    def test_compare_same(self):
        result = compare_life_paths(5, 5)
        self.assertIn("same Life Path", result)

    def test_compare_a_greater(self):
        result = compare_life_paths(7, 3)
        self.assertIn("Person A has a higher", result)

    def test_compare_b_greater(self):
        result = compare_life_paths(3, 9)
        self.assertIn("Person B has a higher", result)

    def test_parse_birthday_valid(self):
        self.assertEqual(parse_birthday("13-11-1987"), [13, 11, 1987])

    def test_is_master_true(self):
        self.assertTrue(is_master_number(11))

    def test_is_master_false(self):
        self.assertFalse(is_master_number(10))

    def test_get_lucky_color_valid(self):
        self.assertEqual(get_lucky_color(1), "Red")

    def test_get_lucky_color_unknown(self):
        self.assertEqual(get_lucky_color(15), "Unknown")


if __name__ == '__main__':
    unittest.main()

