# get_generation.py

def get_generation(year):
    if 1925 <= year <= 1945:
        return "Silent Generation"
    elif 1946 <= year <= 1964:
        return "Baby Boomer"
    elif 1965 <= year <= 1980:
        return "Generation X"
    elif 1981 <= year <= 1996:
        return "Millennial"
    elif 1997 <= year <= 2012:
        return "Generation Z"
    elif 2013 <= year <= 2025:
        return "Generation Alpha"
    else:
        return "Invalid year range"

# Test the function
if __name__ == "__main__":
    y = int(input("Enter your birth year: "))
    print("You belong to:", get_generation(y))
