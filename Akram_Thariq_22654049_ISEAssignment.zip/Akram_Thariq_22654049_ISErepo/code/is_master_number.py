# is_master_number.py

def is_master_number(n):
    return n in [11, 22, 33]

# Testing block
if __name__ == "__main__":
    test_numbers = [11, 4, 22, 33, 9, 44]
    for num in test_numbers:
        print(f"{num} is a master number? {is_master_number(num)}")
        
