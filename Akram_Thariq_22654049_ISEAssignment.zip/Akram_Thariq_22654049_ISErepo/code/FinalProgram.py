# FinalProgram.py

from parse_birthday import parse_birthday
from calculate_life_path import calculate_life_path
from is_master_number import is_master_number
from get_lucky_color import get_lucky_color
from get_generation import get_generation

def main():
    print("Welcome to the Life Path Analyzer")
    print("This program will calculate your Life Path Number based on your date of birth.")
    print("You'll also find out if it's a master number, your lucky colour, and your generation.")
    print()

    try:
        birthday_input = input("Please enter your date of birth (DD-MM-YYYY): ")
        day, month, year = parse_birthday(birthday_input)

        # Step 1: Life Path Number
        life_path = calculate_life_path(day, month, year)
        print(f"\nYour Life Path Number is: {life_path}")

        # Step 2: Master Number Check
        if is_master_number(life_path):
            print("This is a Master Number.")
        else:
            print("This is not a Master Number.")

        # Step 3: Lucky Colour
        color = get_lucky_color(life_path)
        print(f"Your Lucky Colour is: {color}")

        # Step 4: Generation
        generation = get_generation(year)
        print(f"You belong to: {generation}")

    except Exception as e:
        print(f"An error occurred: {e}")
        print("Please restart the program and enter a valid date.")

if __name__ == "__main__":
    main()

