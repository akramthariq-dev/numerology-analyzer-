# get_lucky_color.py

def get_lucky_color(life_path_number):
    color_map = {
        1: "Red",
        2: "Orange",
        3: "Yellow",
        4: "Green",
        5: "Sky Blue",
        6: "Indigo",
        7: "Violet",
        8: "Magenta",
        9: "Gold",
        11: "Silver",
        22: "White",
        33: "Crimson"
    }

    return color_map.get(life_path_number, "Unknown")

# Test the function
if __name__ == "__main__":
    number = int(input("Enter your Life Path Number: "))
    print("Your lucky color is:", get_lucky_color(number))

