# calculate_life_path.py

def calculate_life_path(day, month, year):
    def sum_digits(n):
        return sum(int(d) for d in str(n))

    def reduce_number(n):
        if n in [11, 22, 33]:
            return n
        while n > 9:
            n = sum_digits(n)
        return n
        
    if day == 0 or month == 0 or year == 0:
        raise ValueError("Invalid date input")

    # Step 1: reduce each part, but keep master numbers
    day_sum = reduce_number(day)
    month_sum = reduce_number(month)
    year_sum = reduce_number(year)

    total = day_sum + month_sum + year_sum

    # Step 2: reduce total only if not a master number
    return total if total in [11, 22, 33] else reduce_number(total)

# Testing block
if __name__ == "__main__":
    result = calculate_life_path(13, 11, 1987)
    print("Life Path Number:", result)

