# parse_birthday.py
#TODO: Add validation in the future
def parse_birthday(birthday_str):
    try:
        parts = birthday_str.split('-')
        if len(parts) != 3:
            raise ValueError("Invalid format")
        day, month, year = map(int, parts)
        if not (1 <= day <= 31 and 1 <= month <= 12 and year > 0):
            raise ValueError("Invalid date components")
        return [day, month, year]
    except Exception as e:
        raise ValueError("Invalid input") from e

# Run the function
if __name__ == "__main__":
    print(parse_birthday("13-11-1987"))

