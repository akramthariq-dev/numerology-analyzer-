# compare_life_paths.py

def compare_life_paths(path1, path2):
    """
    Compare two Life Path Numbers and return a message indicating their relationship.
    """

    if path1 == path2:
        return f"Both people have the same Life Path Number: {path1}"
    elif path1 > path2:
        return f"Person A has a higher Life Path Number ({path1}) than Person B ({path2})"
    else:
        return f"Person B has a higher Life Path Number ({path2}) than Person A ({path1})"


# Testing block
if __name__ == "__main__":
    result = compare_life_paths(7, 7)  # You can change these values for testing
    print(result)
# compare_life_paths.py
